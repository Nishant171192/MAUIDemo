﻿namespace com.kpmgus.linkworkforcemobile;

public partial class App : Application
{
	public App()
	{
		InitializeComponent();

		MainPage = new AppShell();
	}
}

