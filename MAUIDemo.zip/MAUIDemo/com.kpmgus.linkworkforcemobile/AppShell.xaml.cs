﻿namespace com.kpmgus.linkworkforcemobile;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}

